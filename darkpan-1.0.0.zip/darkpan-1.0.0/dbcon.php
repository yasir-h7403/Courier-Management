<?php
    $server = "mysql:host=localhost;dbname=couriers";
    $user = "root";
    $pass = "";
    $pdo = new PDO($server, $user, $pass);
?>