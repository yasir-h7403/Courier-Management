<?php
    include('dbcon.php');
    session_start();
    // signin page
    if(isset($_POST["signin"])){
        $useremail = $_POST["email"];
        $userpassword = $_POST["password"];
        $query = $pdo->prepare("select * from admin where email = :Email AND password = :Password");
        $query->bindParam("Email", $useremail);
        $query->bindParam("Password", $userpassword);
        $query->execute();
        $res = $query->fetch(PDO::FETCH_ASSOC);
        if($res){
            $_SESSION["email"] = $res["email"];
            echo"<script>alert('signin successful');
                location.assign('index.php')
                </script>";
        }
    }
?>