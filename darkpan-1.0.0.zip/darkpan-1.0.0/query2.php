<?php
include('dbcon.php');
if(isset($_POST['Shipment'])){
    $sendername = $_POST['name'];
    $sendadderss = $_POST['sendaddress'];
    $weightkg = $_POST['weight_kg'];
    $city = $_POST['city'];
    $receiver_address = $_POST['receiver_address'];
          $query = $pdo->prepare("insert into shipment(sender_name,sender_address,weight_kg,city,receiver_address) values(:name,:sendadderss,:weight_kg,:city,:receiver_address)");
          $query->bindParam('name',$sendername);
          $query->bindParam('sendadderss',$sendadderss);
          $query->bindParam('weight_kg',$weightkg);
          $query->bindParam('city',$city);
          $query->bindParam('receiver_address',$receiver_address);
          $query->execute();
          echo "<script>alert('courier successfully  delevery in  destination');
          </script>";
       }
    

?>

